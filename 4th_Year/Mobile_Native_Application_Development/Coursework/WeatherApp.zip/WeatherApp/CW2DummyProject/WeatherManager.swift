//
//  WeatherManager.swift
//  CW2DummyProject
//
//  Created by Visal Rajapakse on 2022-04-02.
//

import Foundation

// Performs the Async call + Updates the view based on the new values
