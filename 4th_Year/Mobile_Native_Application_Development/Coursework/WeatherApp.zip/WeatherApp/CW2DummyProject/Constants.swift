//
//  Constants.swift
//  CW2DummyProject
//
//  Created by Visal Rajapakse on 2022-04-02.
//

import Foundation

enum APIConstants {
    static let key: String = "ADD YOUR API KEY HERE" // <- Add your OpenWeather API Key here
}
