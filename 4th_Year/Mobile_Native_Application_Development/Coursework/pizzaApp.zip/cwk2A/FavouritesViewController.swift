//
//  FavouritesViewController.swift
//  cwk2A
//
// Edited by Girish on 11/12/2021.
//

import UIKit

class FavouritesViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    
    */

}
